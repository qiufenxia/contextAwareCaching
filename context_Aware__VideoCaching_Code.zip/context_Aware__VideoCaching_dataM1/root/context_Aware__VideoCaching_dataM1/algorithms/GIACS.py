# written by biya
from matplotlib import pyplot as plt
from Graph import ParameterSetting as PS
import numpy as np
import torch
import math
from Graph import data0 as dat
from contrastTestHelp.FM import *
from contrastTestHelp.MLP import *

##sigmod函数合并
# 初始化，处理数据，接收到的应该是每个user现有context[item,[]]
# return 归一化后的list， 为调整为矩阵
"""
 1. 处理数据：获取list集合【【f1：user年龄，f2：movie类别，label：评分】】均做归一化处理 √
 2. 得到 mlp和fm预测到的值并处理
 Z_fm: eg:[0.6227897275469301]
 Z_mlp eg:[[0.91643584]]
 3. 计算 loss
    计算 user interest
 4. 缓存
 :return:
"""
class GIACSclass:
    def __init__(self, uid):
        self.uid = uid
        # self.data = data
        self.Feature = []
        self.Label = []
        self.needToCacheItems = None
        self.item = []
        self.X = None

    def set_toCacheContent(self,item0):
        self.item = item0

    def predictDataProcess(self):
        feature = []
        vid = self.item[0]
        feature.append(dat.video_dict[vid]['charac'][0])
        # 根据uid 去获取user 的年龄
        feature.append(PS.Get_UserParam0(self.uid, 'Age'))
        self.X = self.normalization(feature)

    def dataProcessing(self, data): #连带着测试集一起数据归一化处理
        Feature = []
        Label = []
        for item in data:
            Label.append(item[1])
            #根据vid 去获取 video类别
            vid = item[0]
            feature = []
            feature.append(dat.video_dict[vid]['charac'][0])
            # 根据uid 去获取user 的年龄
            feature.append(PS.Get_UserParam0(self.uid, 'Age'))

            Feature.append(feature)
        F0 = self.min_max(Feature)
        self.Feature = F0[:-1]
        self.Label = self.normalization(Label)[:-1]
        self.X = F0[-1]

    ##-----------------------------------------工具方法------------------------
    # 多维矩阵的归一化处理 矩阵元素调整到[0,1]
    def min_max(self, data):
        self.data = data
        min_max_scaler = preprocessing.MinMaxScaler()
        return min_max_scaler.fit_transform(self.data)

    # 单维矩阵归一化处理
    def normalization(self, data):
        _range = np.max(data) - np.min(data)
        print("data：{}，np.min(data):{},_range:{}".format(data,np.min(data),_range))
        return (data - np.min(data)) / _range

    # -------------------------------以上均是对数据进行处理------------------
    # 合并
    def getZ_forOneUser(self):

        print("输出处理后的Feature is{}，Label is {}".format(self.Feature, self.Label))

        # 调用FM类得到Z_fm
        FM = FMclass(self.Feature, self.Label)
        FM.fit(feature_potential=8, alpha=0.01, iter=100)

        # 预测特征
        m = []
        m.append(self.X)
        print("处理之后的test数据是",m)
        Z_fm = FM.predict(m)
        print("预测出来的Z_fm是{}".format(Z_fm))


        # 调用MLP算法计算 Z_mlp
        MLP = MLPclass(self.Feature, self.Label)
        MLP.fit()
        Z_mlp = MLP.predict(self.X)
        print("预测出来的Z_mlp是{}".format(Z_mlp))
        return Z_fm, Z_mlp

    def mergeZ(self, Z_fm, Z_mlp):
        # 传进来的是当前轮次的Z_fm以及Z_mlp所有元素的list[]
        fm = np.array([Z_fm])
        # fm = fm.astype(np.float64)
        mlp = np.array([Z_mlp])
        # mlp = np.around(mlp,5)

        # Z_fm 与 Z_mlp 合并
        Z = ((fm.T).dot(mlp))
        Z=np.around(Z, decimals = 5)
        print("传进来的fm是{}， mlp是{}， 形成的预测矩阵是{}".format(fm,mlp,Z))
        Z_= torch.sigmoid(torch.from_numpy(Z))
        print("本轮次中[0,1]处理之后的结果是：")
        print(Z_)
        diag = torch.diag(Z_)
        return diag.numpy()  # 当前user对所有item的预测值

    def sigmoid(self, inx):
        # return 1.0/(1+exp(min(max(-inx,-10),10)))
        return 1.0 / (1 + exp(-inx))

    def sigmoid_function(z):
        fz = []
        for num in z:
            fz.append(1 / (1 + math.exp(-num)))
        return fz



