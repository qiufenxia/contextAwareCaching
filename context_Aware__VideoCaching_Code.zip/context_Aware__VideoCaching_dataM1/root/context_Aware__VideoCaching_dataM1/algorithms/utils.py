import networkx as nx
from networkx.algorithms import all_pairs_dijkstra_path_length
from code_utils import lpsolve_wrapper  as lw
# import lpsolve_wrapper as lw
import numpy as np
np.set_printoptions(threshold=np.inf) #不间断打印数组


def uckm(distances, numClient, numFacility):
    """

    :param distances: 优化目标 使其最小
    :param numClient: 对应segment
    :param numFacility: 对应user device
    :return: 存储位置
    """
    # since capacity == 1, no need to determine the open facilities set,
    # so degrade into algorithm in chapter 3.1 of UCKM reference
    print('UCKM algorithm, segment:', numClient,' device: ', numFacility)
    #创建求解器实例，并添加两个变量
    model = lw.Model(
        notations={
            'x': lw.notation(
                shape=(numClient, numFacility),
                lower_bound=0,
            )
        })
    # 通过传入回调函数添加约束,例如：sum(x)<1
    for i in range(numClient):
        model.add_constr_callback(
            callbacks={
                'x': lambda x: x[i, :].fill(1)
            },
            right_value=1,
            constr_type = lw.EQ
            #sum(_) =1
        )
    for j in range(numFacility):
        model.add_constr_callback(
            callbacks={
                'x': lambda x: x[:, j].fill(1)
            },
            right_value = 1,
            constr_type = lw.LEQ
            # sum(_) <=1
        )
    #求解
    objective, notation_list = model.lp_solve(
        obj_func={
            'x': distances,
        },
        minimize = True
    )

    print("result from uckm:", notation_list['x'])
    return notation_list['x']

if __name__ == '__main__':
    pass
