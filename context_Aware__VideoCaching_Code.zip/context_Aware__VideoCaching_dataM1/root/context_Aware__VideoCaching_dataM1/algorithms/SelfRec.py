# written by biya
"""实现自我推荐策略：self-recommendation policy
  item 向user组进行缓存，每个user对item都有各自评分，查一下高于2分的就进行存储
"""
from Graph import ParameterSetting as PS
from Graph import data0 as dat

class simpleAlgClass(object):
    def __init__(self, itemSet, uid):
        """
        :param itemSet: 本轮要缓存的item集合
        :param uid: 本轮请求用户
        """
        self.itemSet = itemSet
        self.uid = uid

    def contentForUser(self):
        contentId = []
        for item in PS.Get_User_Rate_Video(self.uid):
            contentId.append(item[0])
        return contentId

    def selfRec(self, weight, cache_aveRate, Electricity, cacheSize, cacheContent):
        contentId = self.contentForUser()
        sizeSegbySelfRec = 0
        ElecBSelfRec = 0
        DelayBySelfRec = 0
        num = 0
        cacheContentId = [item[0] for item in cacheContent]
        for item in self.itemSet:
            # 判断item是否在uid的观看历史里，若存在 判断评分是否高于2分，若成立该用户缓存当前item ，计算delay
            vid = item[0]
            if (vid in contentId and PS.Get_User_Rate_Video(self.uid)[contentId.index(vid)][1] > 2) or (
                    vid not in contentId and cache_aveRate > 2):
                if cacheSize < dat.video_dict[vid]['size']:
                    for cachedId in cacheContentId:
                        cacheContentId.remove(cachedId)
                        cacheSize += dat.video_dict[cachedId]['size']
                        if cacheSize >= dat.video_dict[vid]['size']:
                            break
                if cacheSize >= dat.video_dict[vid]['size']:
                    num += 1
                    sizeSegbySelfRec += dat.video_dict[vid]['size']
                    cacheSize -= dat.video_dict[vid]['size']
                    # ElecByICME += Electricity
                    DelayBySelfRec += weight / PS.Get_LaunchPower() + dat.video_dict[vid][
                        'size'] / PS.Get_UpstreamRate() \
                                   + dat.video_dict[vid]['size'] / PS.Get_DownloadRate()

        return sizeSegbySelfRec/num if num!=0 else 0, num, DelayBySelfRec, cacheSize

    def cacheAlginICME(self, weight, Electricity, cacheSize, cacheContent):
        sizeSegbyICME = 0
        ElecByICME= Electricity
        DelayByICME = 0
        num = 0 # 记录缓存内容的数目
        # ICME那篇文章中提出的算法实现
        # 根据当前的内容流行度缓存内容(前3组[0，2]设置为deta1，[3，19]设置为deta2，剩下80组设置为deta3)
        deta1, deta2, deta3 = PS.Get_deta()
        cacheContentId = [item[0] for item in cacheContent]
        for item in self.itemSet:
            # 判断item是否在uid的观看历史里，若存在 判断评分是否高于2分，若成立该用户缓存当前item ，计算delay
            vid = item[0]
            if vid in deta1:
                if cacheSize < dat.video_dict[vid]['size']:
                    for cachedId in cacheContentId:
                        if cachedId in (deta3 or deta2):
                            cacheContentId.remove(cachedId)
                            cacheSize += dat.video_dict[cachedId]['size']
                        if cacheSize >= dat.video_dict[vid]['size']:
                            break
                if cacheSize >= dat.video_dict[vid]['size']:
                    num += 1
                    sizeSegbyICME += dat.video_dict[vid]['size']
                    cacheSize -= dat.video_dict[vid]['size']
                    # ElecByICME += Electricity
                    DelayByICME += weight / PS.Get_LaunchPower() + dat.video_dict[vid][
                        'size'] / PS.Get_UpstreamRate() \
                                      + dat.video_dict[vid]['size'] / PS.Get_DownloadRate()
                # 判断缓存空间是否可用，若不可用 按deta3到deta1的顺序排序删除

        return sizeSegbyICME/num if num!=0 else 0, num, DelayByICME, cacheSize
        # 被useri缓存的seg的平均size, user i 缓存的数目, 缓存这些内容user i 所需时延, user i 剩余缓存空间







