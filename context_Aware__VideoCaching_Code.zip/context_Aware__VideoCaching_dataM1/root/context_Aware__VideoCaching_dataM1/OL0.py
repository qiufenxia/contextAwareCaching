# written by biya
import os
from Graph.Cont import *
from Graph import ParameterSetting as PS
from Graph import FileReader as FR, GraphHelper as GH, Dag as D
from Graph import AuxiliaryNetwork as AN
from Graph import data0 as dat
from entity.UserEntity import *
from offline import *
from DataHelp import dataHelp as dh
from algorithms.GIACS import GIACSclass as giacs
from algorithms.SelfRec import simpleAlgClass as simpleAlgs
import random
import copy
import tensorflow as tf
import os
import  time

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)


NetworkList = [30, 50, 100, 200]
FileName = '200-25-25.txt'
FilePath = "data/"
Users = PS.Get_UserParam() # 处理user文件 得到user信息 {Users:{uid:{'Gender':,'Age':,'Occupation':}}}

# get NodeSet, EdgeSet  # list
dataReader = FR.MyFileReader()
NodeSet, EdgeSet = dataReader.Get_Graph_Information(FilePath, FileName) # 读取 节点 和 边的文件 得到节点和边的信息
NetworkData = GH.NetworkTepology(NodeSet, EdgeSet)
NetworkData.Build_Network_Tepology() # 初始化网络
UserEntity0 = NetworkData.UserList  # {[{UpstreamRate, downloadRate, Memory, Electricity，LaunchPower，cache_content_size}],[],[],...}
UsersFromUserEntuty0 = CopyUserEntity(UserEntity0)
UserEntity = UsersFromUserEntuty0.Get_Users()

d = random.randint(50, 200)  # the numbe r of users in a community
N, Community, Community_num, neiborUserDict, NAp, NAp_edge = AN.ConstructLayer(NetworkData, NodeSet, EdgeSet, d)
#NAp_edge: {(1, 113): 25, (1, 94): 37, (1, 'bs0'): 278, (113, 'bs0'): 295, (94, 'bs0'): 271, (2, 112): 31, (2, 'bs1'): 161, (112, 4): 30, (112, 132): 22，...}
NetworkData.Build_BS(Community)  # builde the bs in the community 生成了一张网络图
BSEntity = NetworkData.BSList
SegmentGroup = []


for com in range(Community_num):

    userSet0 = Community[com]

    for t in range(10):
    # for t in range(10):
        k = 0
        Delay = []
        ResCache = []
        Electricity = []

        DelayByGiacs = []
        ResCacheBySGiacs = []
        ElecByGiacs = []

        DelayOnlyByuckm = []
        ResCacheOnlyByuckm = []
        ElectricityOnlyByuckm = []

        DelayBySelfRec = []
        ResCacheBySelfRe = []
        ElecBySelfRec = []

        DelayBySelfICME = []
        ResCacheBySelfICME = []
        ElecBySelfICME = []

        # 记录每一轮 user上的内容缓存到其它用户上的时延 和 电量
        for user in userSet0:



            # user's neibourSet
            """这块可以改成整个community的user之间的通信"""
            userSet = neiborUserDict[user]
            print("user{}:可选择的用户数目（每轮要记录，作为观测指标之一,因变量：可进行缓存的UE数目）:{}".format(user, userSet))
            if len(userSet) < 10: continue
            print("user{}:看一下最多邻居用户能多少个:{},分别是{}".format(user, len(userSet), userSet))

            # 记录当前环境内的上下文情况，计数
            # 要缓存的内容
            # contentToCache = UsersFromUserEntuty0.Get_userContent(user)['cache_content']


            user_loss = []        # 记录所有可通信用户的loss情况
            predictedResult = {}  # 记录所有可通信用户对于Q级视频分组的预测概率
            preResByGIACS = []
            contentToCache = UsersFromUserEntuty0.Get_userContent(user)['cache_content']

            """—---------------— 对比实验2、3  变量 —----------------—"""
            sumSizeSegbySelfRec = 0
            sumElecBySelfRe = 0
            sumDelayBySelfRe = 0
            sumSegbySelfRecs = 0
            sumResCacheBySelfRe = 0

            sumSizeSegbyICME  = 0
            sumElecByICME = 0
            sumDelayByICME = 0
            sumSegbyICME = 0
            sumResCacheByICME = 0
            cacheSizes = []


            # 当前user的可通信节点,对应OL中的第4行 segment的潜在传输对象
            for i in userSet:
                cacheSizes.append(UsersFromUserEntuty0.Get_userContent(i)["Memory"] - UsersFromUserEntuty0.Get_userContent(i)[
                    "cache_content_size"])
                print("当前的userid为{},userSet为{}".format(i, userSet))
                result = []       # 每一个user 对Q级请求概率的预测
                userContent = UsersFromUserEntuty0.Get_userContent(i)

                """记录当前轮次该user的上下文信息及损失函数"""

                for item in userContent['cache_content']:  # 每一轮都在更新
                    #记录上下文信息 初始化（每个上下文都有一个累计损失函数，假设是内容从基站获得的，进而产生相应时延）
                    # 若当前item 不存在于 useri 的context中 才添加 ；已经存在不添加
                    if UsersFromUserEntuty0.IncludedInContexts(i, item[0]) is False:
                        if t == 0:
                            item_context = Context(NAp_edge[(i,'bs'+str(com))], i, item[0], item[1], userContent, Users[i])
                        else:
                            item_context = Context(NAp[user][i]["weight"],i, item[0], item[1], userContent, Users[i])
                        UsersFromUserEntuty0.Set_Context(i, item_context)

                """对上面 context 生成的 loss 进行分组处理：
                   1. 获取当前user的groups，判断是否第一次调用（即为空），为空：按照上面的loss 划分interval，初始化分组内容
                   2. 不空（代表之前有一些初始值），调整分组 但是此时空contextId 对应的minLoss 不一定为1
                """
                # groups 记录的是每个user上 loss分组
                user_loss ,groups = UsersFromUserEntuty0.Get_UserGroup(i)

                """现在有5组上下文分组（group），每个分组在训练的过程中需要不断的更新，每组选取loss最小的上下文并计算其请求概率"""
                # probabilityOfContextWithMinLoss = []
                for id in range(5):
                    # 若当前group中有context
                    if groups[id]['minLoss'] != 1: # 说明是初始化之后的内容
                        # 记录当前group中 useri对Q级内容的预测概率
                        probabi = update_probability_representative(groups[id]['minLoss'], user_loss)
                        groups[id]['probability'] = probabi

                        # 在更新的过程中contextId组和minLoss 要同步更新
                        vid = groups[id]['minLossId']
                        # 记录各级别以及对应的推荐概率，写一个查询当前是频段所在level的方法!!!!这块有问题，相同级别概率容易被覆盖
                        result.append({"level":PS.Get_videoCount()[vid],"probability":probabi})
                        # result0["Group"+str(id)] = {"level":PS.Get_videoCount()[vid],"probability":probabi}
                    # print("id是{}，当前的group[id]['minLoss']是{}，probabi是{}".format(id, group[id]['minLoss'], group[id]['probability']))
                UsersFromUserEntuty0.Set_UserGroup(i,groups)

                # 此时所有neiuser请求QGroup的概率：例子：{'user196': {{}，{}，{}，... ，}，'user1':{},...,}
                # 也就是得到每个user device 的 capacity
                predictedResult["user" + str(i)] = result

                """—---------------— 对比实验2、3 —共有变量 —----------------—"""
                algs = simpleAlgs(contentToCache, i)
                remainMeomry = userContent["Memory"] - userContent["cache_content_size"]


                """—---------------— 对比实验3 —ICME(和对比实验2一起封装到SelfRec类里了)—起始线 —----------------—"""
                # 被useri缓存的seg的平均size, user i 缓存的数目, 缓存这些内容user i 所需时延, user i 剩余缓存空间
                sizeSegbyICME, cacheNumByICME, delayByICME, resCacheByICME = algs.cacheAlginICME(NAp[user][i]["weight"], userContent["Electricity"],
                                                                                                 remainMeomry,
                                                                                                 userContent['cache_content'])
                sumSizeSegbyICME += sizeSegbyICME
                # sumElecByICME += ElecByICME
                sumSegbyICME += cacheNumByICME
                sumDelayByICME += delayByICME
                sumResCacheByICME += resCacheByICME
                """—————————————————— 对比实验3 —ICME—终止线 —————————————————"""


                """—---------------— 对比实验2 —selfRec—起始线 —----------------—"""

                # algs = simpleAlgs(contentToCache, i)
                sizeSegbySelfRec, cacheNumBySelfRe, delayBySelfRe, resCacheBySelfRe  = algs.selfRec(NAp[user][i]["weight"], userContent["cache_aveRate"], userContent["Electricity"], remainMeomry,
                                                                           userContent["cache_content"])
                sumSizeSegbySelfRec += sizeSegbySelfRec
                # sumElecBySelfRe += ElecBySelfRe
                sumSegbySelfRecs += cacheNumBySelfRe
                sumDelayBySelfRe += delayBySelfRe
                sumResCacheBySelfRe += resCacheBySelfRe
                """—————————————————— 对比实验2 —selfRec—终止线 —————————————————"""

                """—----------—对比实验1 giacs   start—----------------—"""
                gia = giacs(i)  # uid, data: ui上的现有item[]（训练集）

                trainContent = userContent["cache_content"]
                Z_fm = []
                Z_mlp = []
                for item0 in contentToCache:
                    trainContent.append(item0)
                    print("当前的item0 是{}".format(item0))
                    gia.dataProcessing(trainContent)
                    # gia.set_toCacheContent(item0)  # 将要预测的数据item传进去
                    z_fm, z_mlp = gia.getZ_forOneUser()  # 得到当前轮次的预测Z
                    Z_fm.append(float(z_fm))
                    Z_mlp.append(float(z_mlp))
                print("集合Z_fm:{},Z_mlp:{}".format(Z_fm,Z_mlp))
                predict_useri = gia.mergeZ(Z_fm, Z_mlp)
                preResByGIACS.append(predict_useri)
            print("preResByGIACS is {}".format(preResByGIACS))
            # 得到userSet每个user的预测概率 取均值得到 该user组中对各个内容的预测数据
            groupForEachItem = np.mean(preResByGIACS, axis=0)
            print("groupForeachItem is {}".format(groupForEachItem))
            # 对预测概率排序，缓存top-k个内容到所有地方
            b = sorted(enumerate(groupForEachItem), key=lambda x: x[1])  # [(下标，数值1)，（下标，数值2）]（数值按从小到大排序）
            segmentIDToCacheByGiacs = []
            ElecByGi = 0
            DelayByGi = 0
            sizeSegbyGi = 0
            numByGi = 0
            anotherCacheSizes = copy.deepcopy(cacheSizes)
            for b0 in b:
                if b0[1] > 0.6:
                    vid = contentToCache[b0[0]][0]
                    segmentIDToCacheByGiacs.append(vid)
                    numByGi += 1

                    for j in range(len(userSet)):
                        id = userSet[j]
                        cacheSize = cacheSizes[j]
                        if cacheSize < dat.video_dict[vid]['size']:
                            sizeSegbyGi += dat.video_dict[vid]['size']
                            cacheSizes[j] -= dat.video_dict[vid]['size']
                            # ElecByGi += UserEntity[i]["Electricity"]
                            DelayByGi += NAp[user][id]["weight"]   / PS.Get_LaunchPower() + dat.video_dict[vid]['size'] / PS.Get_UpstreamRate() \
                             + dat.video_dict[vid]['size'] / PS.Get_DownloadRate()

            print("segmentIDToCacheByGiacs is {}".format(segmentIDToCacheByGiacs))
            """————————————对比实验1 giacs 终止线——————————"""

            """—---------------— 记录每一轮user分配情况的数据 —----------------—"""
            # 记录该user组中被分发device的剩余能量
            if sizeSegbyGi != 0:
                DelayByGiacs.append(DelayByGi / sizeSegbyGi/ len(userSet))
                ResCacheBySGiacs.append( sum(cacheSizes) / len(userSet))
                # ElecByGiacs.append(ElecByGi / len(segmentIDToCacheByGiacs))

            if sumSizeSegbySelfRec != 0:
                DelayBySelfRec.append(sumDelayBySelfRe / sumSizeSegbySelfRec / len(userSet))
                ResCacheBySelfRe.append( sumResCacheBySelfRe / len(userSet))
                # ElecBySelfRec.append(sumElecBySelfRe / (sumSegbySelfRecs - 1) )

            if sumSizeSegbyICME != 0:
                DelayBySelfICME.append(sumDelayByICME / sumSizeSegbyICME / len(userSet))
                ResCacheBySelfICME.append(sumResCacheByICME / len(userSet))

                # ElecBySelfICME.append(sumElecByICME / (sumSegbyICME - 1) )
            """—————————————————— 记录每一轮user分配情况的数据 —————————————————"""

            # print("user is {},此时的predictedResult0是{}".format(i,predictedResult))
            # predictedResult是{'user196': {'Group0': {'level': 179, 'probability': 0.25001471878012127}, 'Group4': {'level': 1725, 'probability': 0.2500018321525146},

            # 调用uckm算法：segment 和 device（已知，并且他们各自对segment的Q组的请求概率已知）
            # 记录要分发的segment，即user0上的所有视频id，以及其对应的Qlevel
            segmentToDistributeID = []
            segmentToDistributeQLevel = []
            mainuserContent = UsersFromUserEntuty0.Get_userContent(user)


            for user0_item in mainuserContent['cache_content']:
                segmentToDistributeID.append(user0_item[0])
                segmentToDistributeQLevel.append(PS.Get_videoCount()[user0_item[0]])
            print("user {}'s cachedVID is {} and the level is {}".format(user,segmentToDistributeID,segmentToDistributeQLevel))
            # 比较的时候对要分发的segment的level采取[level - 3, level +3)的测略，扩大命中范围并且还有利于请求新的内容

            # print("我先看下现在的NAp[user]的值是啥{}".format(NAp[user]))
            # 返回每个segment的缓存位置
            result, cacheLocation, cacheLocaUCKM = offline(NAp[user], UserEntity, user, userSet, 1, predictedResult)
            # print("当前的cacheLocation is {}".format(cacheLocation))
            # 根据返回结果，更新 userSet 中各 user 的缓存内容
            delayOfPlace = 0
            sizeOfSeg = 0
            resCacheSize = 0
            Elec = 0
            for cache_item in cacheLocation:
                # 找到userid 为i的缓存内容并更新  √
                deviceId = cache_item['deviceId']
                segId = cache_item['segId']
                delay = cache_item['delay']
                # 判断是否能装下，能加进去 size - size0 ,否移除对应内容 加进去
                # print("原来的内容是{}".format(UsersFromUserEntuty0.Get_userContent(deviceId)['cache_content']))
                # 得到内容放置后的delay以及放置内容的size总和
                delayPlace, sizeSeg, resCache= UsersFromUserEntuty0.Update_UserContent(deviceId, segId, delay)
                delayOfPlace += delayPlace
                sizeOfSeg += sizeSeg
                resCacheSize += resCache
                Elec +=  UserEntity[deviceId]["Electricity"]
                # 更新上下文 和 loss 理论上存储的内容变了，再次循环的时候也会改变
            Delay.append( delayOfPlace / sizeOfSeg/len(userSet) )
            ResCache.append( resCacheSize /len(cacheLocation))
            # 记录该user组中被分发device的剩余能量
            # Electricity.append(Elec / len(cacheLocation) )

            """——————记录只用uckm得到的结果————————"""
            delayOfPlaceUCKM = 0
            sizeOfSegUCKM = 0
            ElecUCKM = 0
            for cache_item in cacheLocaUCKM:
                # 找到userid 为i的缓存内容并更新  √
                deviceId = cache_item['deviceId']
                segId = cache_item['segId']
                delay = cache_item['delay']
                # 判断是否能装下，能加进去 size - size0 ,否移除对应内容 加进去
                # print("原来的内容是{}".format(UsersFromUserEntuty0.Get_userContent(deviceId)['cache_content']))
                # 得到内容放置后的delay以及放置内容的size总和
                # delayPlace, sizeSeg = UsersFromUserEntuty0.Update_UserContent(deviceId, segId, delay)
                delayuckm = NAp[user][deviceId]["weight"]   / PS.Get_LaunchPower() + dat.video_dict[segId]['size'] / PS.Get_UpstreamRate() \
                         + dat.video_dict[segId]['size'] / PS.Get_DownloadRate()
                delayOfPlaceUCKM += delayuckm
                sizeOfSegUCKM += dat.video_dict[segId]['size']
                ElecUCKM += UserEntity[deviceId]["Electricity"]
                # 更新上下文 和 loss 理论上存储的内容变了，再次循环的时候也会改变
            DelayOnlyByuckm.append(delayOfPlaceUCKM / sizeOfSegUCKM/len(userSet) )
            # 记录该user组中被分发device的剩余能量
            ResCacheOnlyByuckm.append(ElecUCKM / len(cacheLocaUCKM))

            # ElectricityOnlyByuckm.append(ElecUCKM / len(cacheLocaUCKM))


        if DelayOnlyByuckm is not []:
            dh.write_excel_xls_append_d0('delay', DelayOnlyByuckm, com, t, user, len(userSet) )
            dh.write_excel_xls_append_d0('electricity', ResCacheOnlyByuckm, com, t, user, len(userSet))

        if Delay is not []:
            dh.write_excel_xls_append_d0('deOnlyByUCKM', Delay, com, t, user, len(userSet) )
            dh.write_excel_xls_append_d0('elOnlyByUCKM', ResCache, com, t, user, len(userSet))

        if DelayByGiacs is not []:
            dh.write_excel_xls_append_d0('delayByGiacs', DelayByGiacs, com, t, user, len(userSet))
            dh.write_excel_xls_append_d0('elecByGiacs', ResCacheBySGiacs, com, t, user, len(userSet))

        if DelayBySelfRec is not []:
            dh.write_excel_xls_append_d0('delayBySelfRec', DelayBySelfRec, com, t, user, len(userSet))
            dh.write_excel_xls_append_d0('elecBySelfRec', ResCacheBySelfRe, com, t, user, len(userSet))

        if DelayBySelfICME is not []:
            dh.write_excel_xls_append_d0('delayBySelfICME', DelayBySelfICME, com, t, user, len(userSet))
            dh.write_excel_xls_append_d0('elecBySelfICME', ResCacheBySelfICME, com, t, user, len(userSet))


        # 实验目标：获取当前轮次，所有内容分发的平均时延；记录每一轮次segment的平均delay以及平均剩余电量


print("我的朋友，你能跑到这么？")






