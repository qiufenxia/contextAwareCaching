# written by biya
import math

from Graph.Cont import *
from Graph import ParameterSetting as PS
from Graph import FileReader as FR, GraphHelper as GH, Dag as D
from Graph import AuxiliaryNetwork as AN
from Graph import data0 as dat
from entity.UserEntity import *
from offline import *
from DataHelp import dataHelp as dh
from algorithms.GIACS import GIACSclass as giacs
from algorithms.SelfRec import simpleAlgClass as simpleAlgs
import random
import copy
import tensorflow as tf
import os
import  time
import torch
ticks = time.time()

# os.environ["CUDA_VISIBLE_DEVICES"] = '0'
# config = tf.compat.v1.ConfigProto()
# config.gpu_options.per_process_gpu_memory_fraction = 0.9
# sess=tf.compat.v1.Session(config=config)
os.environ['TF_XLA_FLAGS'] = '--tf_xla_enable_xla_devices'
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'
print(tf.__version__)
a = tf.constant(1.)
b = tf.constant(2.)
print(a+b)
print('GPU:', tf.test.is_gpu_available())


def Get_time():
    return time.strftime("%Y-%m-%d  %H:%M:%S    :", time.localtime())

#-----------------------------------------------------------------------
NetworkList = [30, 50, 100, 200]
FileName = '200-25-25.txt'
FilePath = "data/"
Users = PS.Get_UserParam() # 处理user文件 得到user信息 {Users:{uid:{'Gender':,'Age':,'Occupation':}}}

# get NodeSet, EdgeSet  # list
dataReader = FR.MyFileReader()
NodeSet, EdgeSet = dataReader.Get_Graph_Information(FilePath, FileName) # 读取 节点 和 边的文件 得到节点和边的信息
NetworkData = GH.NetworkTepology(NodeSet, EdgeSet)
NetworkData.Build_Network_Tepology() # 初始化网络
UserEntity0 = NetworkData.UserList  # {[{UpstreamRate, downloadRate, Memory, Electricity，LaunchPower，cache_content_size}],[],[],...}
UsersFromUserEntuty0 = CopyUserEntity(UserEntity0)
UserEntity = UsersFromUserEntuty0.Get_Users()

d = random.randint(50, 200)  # the numbe r of users in a community
N, Community, Community_num, neiborUserDict, NAp, NAp_edge = AN.ConstructLayer(NetworkData, NodeSet, EdgeSet, d)
#NAp_edge: {(1, 113): 25, (1, 94): 37, (1, 'bs0'): 278, (113, 'bs0'): 295, (94, 'bs0'): 271, (2, 112): 31, (2, 'bs1'): 161, (112, 4): 30, (112, 132): 22，...}
NetworkData.Build_BS(Community)  # builde the bs in the community 生成了一张网络图
BSEntity = NetworkData.BSList
SegmentGroup = []

def contentForUser(uid):
    contentId = {}
    for item in PS.Get_User_Rate_Video(uid):
        contentId[item[0]] = item[1]
    return contentId

def Get_HitRatio_UserforItem(uid, vid):
    hitRatio = 0
    contentId = contentForUser(uid)
    if id in contentId:
        hitRatio += contentId[vid]
    else:
        cache_aveRate = UsersFromUserEntuty0.Get_userContent(uid)["cache_aveRate"]
        hitRatio += random.uniform((cache_aveRate - 1) if cache_aveRate >= 0 else 0,
                                       (cache_aveRate + 1) if cache_aveRate <= 5 else 5)
    return hitRatio


#探究 com中users数目对5种算法的影响关系 控制传输功率为0.1w,  budget为0.5w（换算单位）
for com in range(Community_num):

    # com = 0
    userSet0 = Community[com]
    # if com == 1 : break
    EnergyBudget = []
    print("{}：user数为{}的com{}；开始遍历".format(Get_time(), com,len(userSet0)))

    # budget= [0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95,1]

    # for t in range(1):
    # for bud in budget: # 遍历budget
    #     t = bud
    bud = 0.5
    k = 0
    print("{}：user以budget{}开始遍历".format(Get_time(), bud))

    DelayByGiacs = []
    ResCacheBySGiacs = []
    ElecByGiacs = []
    HitRatioByGiacs = []
    timeByGiacs = []


    DelayBySelfRec = []
    ResCacheBySelfRec = []
    ElecBySelfRec = []
    HitRatioBySelfRec = []
    timeBySelfRec = []


    DelayBySelfICME = []
    ResCacheBySelfICME = []
    ElecBySelfICME = []
    HitRatioBySelfICME = []
    timeBySelfICME = []


    Delay = []
    ResCache = []
    Electricity = []
    HitRatio = []
    timeOL = []



    DelayOnlyByuckm = []
    ResCacheOnlyByuckm = []
    ElecOnlyByuckm = []
    HitRatioOnlyByuckm = []
    numOfneiUser = []  # 记录每次 内容可分配的user数
    # timeByuckm = []


    print("{}:com_{},该com中有{}users".format(Get_time(), com, len(userSet0)))

    # 记录每一轮 user上的内容缓存到其它用户上的时延 和 电量

    for user in userSet0:
        t=0

        # user's neibourSet
        """这块可以改成整个community的user之间的通信"""
        userSet = neiborUserDict[user]
        # print("{}:user{}:可选择的用户数目（每轮要记录，作为观测指标之一,因变量：可进行缓存的UE数目）:{}".format(Get_time(),user, userSet))
        # if len(userSet) < 10: continue
        print("{}:user{}的邻居用户数(可选择的用户数目):{},分别是{}".format(Get_time(),user, len(userSet), userSet))
        numOfneiUser.append(len(userSet))
        curEntity = UsersFromUserEntuty0.Get_userContent(user)

        # 记录当前环境内的上下文情况，计数
        # 要缓存的内容


        user_loss = []        # 记录所有可通信用户的loss情况
        predictedResult = {}  # 记录所有可通信用户对于Q级视频分组的预测概率
        preResByGIACS = []
        timeByGIACS = []
        contentToCache = curEntity['cache_content']

        """—---------------— 对比实验2、3  变量 —----------------—"""
        sumSizeSegbySelfRec = 0
        sumElecBySelfRe = 0
        sumDelayBySelfRe = 0
        sumTimeBySelfRe = 0
        sumSegbySelfRecs = 0
        sumResCacheBySelfRe = 0
        sumHitRatioBySelfRe = 0
        countUserSelfRe = 0

        sumSizeSegbyICME = 0
        sumElecByICME = 0
        sumDelayByICME = 0
        sumSegbyICME = 0
        sumResCacheByICME = 0
        sumHitRatioByICME = 0
        countUserByICME = 0
        sumTimeByICME = 0
        P_trs = curEntity['LaunchPower']
        numFromBudget = math.floor(bud / P_trs)

        cacheSizes = {}  # 记录邻居用户可缓存空间的大小，用户求每轮的剩余缓存空间
        # 当前user的可通信节点,对应OL中的第4行 segment的潜在传输对象
        numFromBud_ICME = copy.deepcopy(numFromBudget)
        numFromBud_Self = copy.deepcopy(numFromBudget)
        timeByGIACS = 0
        for i in userSet:
            userContent = UsersFromUserEntuty0.Get_userContent(i)
            userContentOfuseri = userContent["cache_content"]
            cacheSizes[i] = (userContent["Memory"] - userContent["cache_content_size"])
            print("{}：我是user{}的邻居之一，userid为{},userSet为{}".format(Get_time(),user,i, userSet))

            result = []       # 每一个user 对Q级请求概率的预测

            """更新当前轮次该user的content信息及损失函数"""

            for item in userContentOfuseri:
                #记录上下文信息 初始化（每个上下文都有一个累计损失函数，假设是内容从基站获得的，进而产生相应时延）
                # 若当前item 不存在于 useri 的context中 才添加 ；已经存在不添加，保证历史信息的持续性和唯一性
                if UsersFromUserEntuty0.IncludedInContexts(i, item[0]) is False:
                    if t == 0:
                        # 首次迭代从基站传输的内容所以记录
                        item_context = Context(NAp_edge[(i,'bs'+str(com))], i, item[0], item[1], userContent, Users[i])
                    else:
                        item_context = Context(NAp[user][i]["weight"],i, item[0], item[1], userContent, Users[i])
                    UsersFromUserEntuty0.Set_Context(i, item_context)

            """
            对上面 context 生成的 loss 进行分组处理：
               1. 获取当前user的groups，判断是否第一次调用（即为空），为空：按照上面的loss 划分interval，初始化分组内容
               2. 不空（代表之前有一些初始值），调整分组 但是此时空contextId 对应的minLoss 不一定为1
            """
            # groups 记录的是每个user上 loss分组
            user_loss ,groups = UsersFromUserEntuty0.Get_UserGroup(i)

            """现在有5组上下文分组（group），每个分组在训练的过程中需要不断的更新，每组选取loss最小的上下文并计算其请求概率"""

            for id in range(5):
                # 若当前group中有context
                if groups[id]['minLoss'] != 1: # 说明是初始化之后的内容
                    # 记录当前group中 useri对Q级内容的预测概率
                    probabi = update_probability_representative(groups[id]['minLoss'], user_loss)
                    groups[id]['probability'] = probabi

                    # 在更新的过程中contextId组和minLoss 要同步更新
                    vid = groups[id]['minLossId']
                    # 记录各级别以及对应的推荐概率，写一个查询当前是频段所在level的方法!!!!这块有问题，相同级别概率容易被覆盖
                    result.append({"level":PS.Get_videoCount()[vid],"probability":probabi})
                    # result0["Group"+str(id)] = {"level":PS.Get_videoCount()[vid],"probability":probabi}
                # print("id是{}，当前的group[id]['minLoss']是{}，probabi是{}".format(id, group[id]['minLoss'], group[id]['probability']))
            UsersFromUserEntuty0.Set_UserGroup(i,groups)

            # 此时所有neiuser请求QGroup的概率：例：{'user196': {{}，{}，{}，... ，}，'user1':{},...,}
            # 也就是得到每个user device 的 capacity
            predictedResult["user" + str(i)] = result

            """—---------------— 对比实验2、3 共有变量 —----------------—"""
            algs = simpleAlgs(contentToCache, i)
            remainMeomry = userContent["Memory"] - userContent["cache_content_size"]

            """—---------------— 对比实验3 —ICME(和对比实验2一起封装到SelfRec类里了)—起始线 —----------------—"""
            # 被useri缓存的seg的平均size, user i 缓存的数目, 缓存这些内容user i 所需时延, user i 剩余缓存空间
            sizeSegbyICME, cacheNumByICME, delayByICME, resCacheByICME, hitRatioByICME, timeByICME = algs.cacheAlginICME(NAp[user][i]["weight"],
                                                                                             userContent["cache_aveRate"],
                                                                                             remainMeomry,
                                                                                             userContentOfuseri,numFromBud_ICME)
            numFromBud_ICME -= cacheNumByICME
            # ElecByICME = PS.Get_Electricity(P_trs, cacheNumByICME)
            ElecByICME = PS.Get_Electricity(P_trs, sizeSegbyICME)

            #缺少命中率和能量消耗
            sumSizeSegbyICME += sizeSegbyICME
            sumElecByICME += ElecByICME
            sumDelayByICME += delayByICME  # 一轮总user缓存内容的累计加和
            sumSegbyICME += cacheNumByICME   # 缓存的Seg数量
            sumResCacheByICME += resCacheByICME if cacheNumByICME != 0 else 0 # 剩余缓存空间的累计加和
            sumHitRatioByICME += hitRatioByICME # 缓存命中率(每个user的评分均值)的累计加和
            countUserByICME += 1 if cacheNumByICME != 0 else 0
            sumTimeByICME += timeByICME


            """—————————————————— 对比实验3 —ICME—终止线 —————————————————"""


            """—---------------— 对比实验2 —selfRec—起始线 —----------------—"""

            # algs = simpleAlgs(contentToCache, i)
            sizeSegbySelfRec, cacheNumBySelfRe, delayBySelfRe, resCacheBySelfRe, hitRatioBySelfRe, timeBySelfRe = algs.selfRec(NAp[user][i]["weight"],
                                                                                                userContent["cache_aveRate"],
                                                                                                remainMeomry,
                                                                                                userContentOfuseri,
                                                                                                numFromBud_Self)
            numFromBud_Self -= cacheNumBySelfRe
            # ElecBySelfRe = PS.Get_Electricity(P_trs, cacheNumBySelfRe)
            ElecBySelfRe = PS.Get_Electricity(P_trs, sizeSegbySelfRec)
            # 同实验3，缺少命中率和能量消耗
            sumSizeSegbySelfRec += sizeSegbySelfRec
            sumElecBySelfRe += ElecBySelfRe         # 这一轮中user  i 缓存内容所用ele
            sumSegbySelfRecs += cacheNumBySelfRe    # 缓存的Seg数量
            sumDelayBySelfRe += delayBySelfRe       #
            sumTimeBySelfRe  += timeBySelfRe
            sumResCacheBySelfRe += resCacheBySelfRe if cacheNumBySelfRe!=0 else 0
            sumHitRatioBySelfRe += hitRatioBySelfRe
            countUserSelfRe +=1 if cacheNumBySelfRe!=0 else 0
            """—————————————————— 对比实验2 —selfRec—终止线 —————————————————"""

            """——————————————》对比实验1 giacs   start--=====》》》-----》---—"""
            startTimeGia = time.time()
            gia = giacs(i)  #创建giacs对象

            # 记录预测出来的结果
            Z_fm = []
            Z_mlp = []
            for item0 in contentToCache:
                trainContent = copy.deepcopy(userContentOfuseri)
                trainContent.append(item0)
                print("当前的item0 是{}".format(item0))
                gia.dataProcessing(trainContent)
                # gia.set_toCacheContent(item0)  # 将要预测的数据item传进去
                z_fm, z_mlp = gia.getZ_forOneUser()  # 得到当前轮次的预测Z
                Z_fm.append(z_fm)
                Z_mlp.append(z_mlp)

            print("{}:集合Z_fm:{},Z_mlp:{}".format(Get_time(),Z_fm,Z_mlp))
            predict_useri = gia.mergeZ(Z_fm, Z_mlp)
            preResByGIACS.append(predict_useri) #记录useri对item集合的预测结果
            endTimeGia = time.time()
            timeByGIACS += endTimeGia - startTimeGia
        print("{}:preResByGIACS is {}".format(Get_time(),preResByGIACS))
        # 得到userSet每个user的预测概率 取均值得到 该user组中对各个内容的预测数据
        groupForEachItem = np.mean(preResByGIACS, axis=0)
        print("{}:groupForeachItem is {}".format(Get_time(),groupForEachItem))
        # 对预测概率排序，缓存top-k个内容到所有地方 k值的选择暂定为长度的70%取地板
        b = sorted(enumerate(groupForEachItem), key=lambda x: x[1],reverse=True)  # [(下标，数值1)，（下标，数值2）]（数值按从小到大排序）
        segmentIDToCacheByGiacs = []

        staTimeByGi = time.time()
        ElecByGi = 0
        DelayByGi = 0
        TimeByGi = 0
        hitRatioByGi = 0
        sizeSegbyGi = 0
        resCacheByGi = 0

        numByGi = 0
        kOfGIACS = math.floor(len(b)*0.7)
        b = b[:kOfGIACS]
        elecByGi = 0

        anotherCacheSizes = copy.deepcopy(cacheSizes)
        for b0 in b:  # b : 要缓存的内容
            if numByGi >= numFromBudget:
                break
            # if b0[1] > 0.57: # 缓存内容概率阈值的选取
            vid = contentToCache[b0[0]][0]
            segmentIDToCacheByGiacs.append(vid)
            resCacheByGi = 0
            # ReqNumOfB = 0

            for id in userSet:
                if numByGi >= numFromBudget:
                    break
                cacheSize = anotherCacheSizes[id]
                if cacheSize >= dat.video_dict[vid]['size'] :
                    sizeSegbyGi += dat.video_dict[vid]['size']
                    anotherCacheSizes[id] -= dat.video_dict[vid]['size']
                    numByGi += 1
                    # ReqNumOfB += 1
                    contentId = contentForUser(id)
                    if vid in contentId:
                        hitRatioByGi += contentId[vid]
                    else:
                        cache_aveRate = UsersFromUserEntuty0.Get_userContent(id)["cache_aveRate"]
                        hitRatioByGi += random.uniform((cache_aveRate - 1.5) if cache_aveRate >= 1.5 else 0,
                                                        (cache_aveRate + 1) if cache_aveRate <= 4 else 5)

                    DelayByGi += NAp[user][id]["weight"] / PS.Get_LaunchPower() + dat.video_dict[vid]['size'] / PS.Get_UpstreamRate() \
                     + dat.video_dict[vid]['size'] / PS.Get_DownloadRate()
                    resCacheByGi += anotherCacheSizes[id]
        timeByGi = time.time() - staTimeByGi
        ElecByGi = PS.Get_Electricity(P_trs, sizeSegbyGi)

        print("{}:segmentIDToCacheByGiacs is {}".format(Get_time(),segmentIDToCacheByGiacs))
        """————————————对比实验1 giacs 终止线——————————"""

        """—---------------— 记录每一轮user分配情况的数据 —----------------—"""
        # 记录该user组中被分发device的剩余能量
        if sizeSegbyGi != 0:
            DelayByGiacs.append(timeByGi / sizeSegbyGi/ numByGi)
            dh.write_excel_xls_append_d0('delayByGiacs', DelayByGiacs[-1], com, len(userSet0), user, len(userSet))

        if sumSizeSegbySelfRec != 0:
            DelayBySelfRec.append(sumTimeBySelfRe / sumSizeSegbySelfRec / countUserSelfRe) # countUserSelfRe表示selfRe缓存内容的用户数目
            dh.write_excel_xls_append_d0('delayBySelfRec', DelayBySelfRec[-1], com, len(userSet0), user, len(userSet))


        if sumSizeSegbyICME != 0:
            DelayBySelfICME.append(sumTimeByICME / sumSizeSegbyICME / countUserByICME )
            dh.write_excel_xls_append_d0('delayBySelfICME', DelayBySelfICME[-1], com, len(userSet0), user, len(userSet))

        """—————————————————— 记录每一轮user分配情况的数据 —————————————————"""

        # print("user is {},此时的predictedResult0是{}".format(i,predictedResult))
        # predictedResult是{'user196': {'Group0': {'level': 179, 'probability': 0.25001471878012127}, 'Group4': {'level': 1725, 'probability': 0.2500018321525146},

        # 调用uckm算法：segment 和 device（已知，并且他们各自对segment的Q组的请求概率已知）
        # 记录要分发的segment，即user0上的所有视频id，以及其对应的Qlevel
        segmentToDistributeID = []
        segmentToDistributeQLevel = []
        mainuserContent = UsersFromUserEntuty0.Get_userContent(user)


        for user0_item in mainuserContent['cache_content']:
            segmentToDistributeID.append(user0_item[0])
            segmentToDistributeQLevel.append(PS.Get_videoCount()[user0_item[0]])
        print("user {}'s cachedVID is {} and the level is {}".format(user,segmentToDistributeID,segmentToDistributeQLevel))
        # 比较的时候对要分发的segment的level采取[level - 3, level +3)的测略，扩大命中范围并且还有利于请求新的内容

        # print("我先看下现在的NAp[user]的值是啥{}".format(NAp[user]))
        # 返回每个segment的缓存位置
        cacheLocation, cacheLocaUCKM = offline(NAp[user], UserEntity, user, userSet, 1, predictedResult)

        """——————记录只用uckm得到的结果————————"""

        delayOfPlaceUCKM = 0
        ElecUCKM = 0
        hitRatio_UCKM = 0
        resCacheOfPlaceUCKM = 0
        sizeOfSegUCKM = 0
        numUCKM = 0
        cacheSizesUCKM = copy.deepcopy(cacheSizes)

        startTimeUCKM = time.time()
        for cache_item in cacheLocaUCKM:
            if numUCKM >= numFromBudget:
                break
            # 找到userid 为i的缓存内容并更新  √
            deviceId = cache_item['deviceId']
            segId = cache_item['segId']
            delayuckm = cache_item['delay']

            cacheContentId = [item[0] for item in UsersFromUserEntuty0.Get_userContent(deviceId)["cache_content"]]
            print("UCKM：device{}目前缓存的内容有{}".format(deviceId,cacheContentId))
            cacheSizeUCKM = cacheSizesUCKM[deviceId]
            segSize = dat.video_dict[segId]['size']

            # if (segId not in cacheContentId):  # 判断当前segment是否在device的现有缓存中
            if cacheSizeUCKM <= segSize:
                for cachedId in cacheContentId:
                    cacheContentId.remove(cachedId)
                    cacheSizesUCKM[deviceId] += segSize
                    if cacheSizesUCKM[deviceId] >= segSize:
                        break
            if cacheSizeUCKM >= segSize :
                numUCKM += 1
                sizeOfSegUCKM += segSize
                cacheSizesUCKM[deviceId] -= segSize
                resCacheOfPlaceUCKM += cacheSizesUCKM[deviceId]
                # cacheContentId.append(segId)

                # ElecByICME += Electricity
                # hitRatio 计算使用评分记录
                # 查看user对该vid的观看记录，若存在，得到其评分记为hitRatio，否则记为(均值-1，均值+1)范围内随机
                conIdUCKM = contentForUser(deviceId)  # 为了后面求hitRatio

                if segId in conIdUCKM:
                    hitRatio_UCKM += conIdUCKM[segId]
                else:
                    cache_aveRate = UsersFromUserEntuty0.Get_userContent(deviceId)["cache_aveRate"]
                    hitRatio_UCKM += random.uniform((cache_aveRate - 1) if cache_aveRate >= 0 else 0,
                                                    (cache_aveRate + 1) if cache_aveRate <= 5 else 5)
            delayOfPlaceUCKM += delayuckm
        timeUCKM = time.time() - startTimeUCKM

            # 更新上下文 和 loss 理论上存储的内容变了，再次循环的时候也会改变
        if numUCKM!=0 :

            DelayOnlyByuckm.append(timeUCKM / sizeOfSegUCKM / numUCKM)
            dh.write_excel_xls_append_d0('deOnlyByUCKM', DelayOnlyByuckm[-1], com, len(userSet0), user, len(userSet))

        """--------------------------------------uckm结束——————————————————————————————————"""

        """——————————————————————————————————————OL开始-----------------------------------"""
        # print("当前的cacheLocation is {}".format(cacheLocation))
        # 根据返回结果，更新 userSet 中各 user 的缓存内容
        delayOfPlace = 0
        sizeOfSeg = 0
        resCacheSize = 0
        Elec = 0
        hitRat = 0
        numOL = 0
        startTimeOL = time.time()
        for cache_item in cacheLocation:
            # 找到userid 为i的缓存内容并更新  √
            if numOL >= numFromBudget:
                break
            deviceId = cache_item['deviceId']
            segId = cache_item['segId']
            delay = cache_item['delay']
            # 判断是否能装下，能加进去 size - size0 ,否移除对应内容 加进去
            # print("原来的内容是{}".format(UsersFromUserEntuty0.Get_userContent(deviceId)['cache_content']))
            # 得到内容放置后的delay以及放置内容的size总和
            delayPlace, sizeSeg, resCache, ratio = UsersFromUserEntuty0.Update_UserContent(deviceId, segId, delay)
            numOL += 1
            delayOfPlace += delayPlace
            sizeOfSeg += sizeSeg
            resCacheSize += resCache
            hitRat += ratio

        TimeOL = time.time() - startTimeOL
            # 更新上下文 和 loss 理论上存储的内容变了，再次循环的时候也会改变
        Elec = PS.Get_Electricity(P_trs, sizeOfSeg)

        if numOL!=0:
            Delay.append( TimeOL / sizeOfSeg/ numOL)
            dh.write_excel_xls_append_d0('delay', Delay[-1], com,len(userSet0), user, len(userSet))

        print("{}:5组数据录入结束".format(Get_time()))

        # 实验目标：获取当前轮次，所有内容分发的平均时延；记录每一轮次segment的平均delay以及平均剩余电量


print("我的朋友，你能跑到这么？")






