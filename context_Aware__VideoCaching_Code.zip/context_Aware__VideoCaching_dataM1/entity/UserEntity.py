# written by biya
from Graph import ParameterSetting as PS
from Graph import data0 as dat
import random
import time


class CopyUserEntity():
    """
    deviceParam = {
                "UpstreamRate" : PS.Get_UpstreamRate(),
                "downloadRate" : PS.Get_DownloadRate(),
                "Electricity": PS.Get_Cl_Electricity(),
                "LaunchPower": PS.Get_LaunchPower(),
                "Memory" : Memory,
                -----------下面的参数都是要在每轮更新的-------------------
                "cache_content_size" : cache_content_size, #已占用的缓存空间的size
                "cache_content": cache_content,
                "cache_aveRate": cache_aveRate,
                "Groups": group,
                "Contexts" : context   // 每个context内部存储：(pathFromBS, id, itemVid , itemVRate, UserEntity, Users)
            }

            UserList [cl] = deviceParam
    """
    def __init__(self,users):
        self.UserList = users

    def Get_Users(self):
        return self.UserList

    def Get_Contexts(self, userId):
        return self.context

    def IncludedInContexts(self, userId, itemVId):
        for context in self.UserList[userId]["Contexts"]:
            if context.Get_vid() == itemVId:
                return True
        return False

    def Set_Context(self, userId, context): # 当前user的contexts和 item一一对应，但是item有可能被剔除，但当前user的context是累加的，所以我应该根据item 的id进行索引
        self.UserList[userId]["Contexts"].append( context )

    def Update_Contexts(self, userId):
        pass

    def Get_ContextsLoss(self, userId):
        loss = []
        for context in self.UserList[userId]["Contexts"]:
            loss.append(context.Get_loss())
        return loss

    def Set_UserGroup(self, userId, Groups):
        self.UserList[userId]['Groups'] = Groups

    def Get_UserGroup(self, userId):
        user_loss = self.Get_ContextsLoss(userId)
        if self.UserList[userId]['Groups'] == []:
            # 按照上面求的user_loss分组,先划分成5组，也就是group组，范围为[最小值-范围的一半, 最小值+范围的一半],[,]....
            max_allLoss = max(user_loss)
            min_allLoss = min(user_loss)
            lenOfLoss = max_allLoss - min_allLoss
            group_interval = lenOfLoss / 4
            startInterval = min_allLoss - group_interval / 2
            # print("max_loss： {} ，min_loss is {}，group_interval is {}".format(max_allLoss, min_allLoss, group_interval))
            for w in range(5):
                endInterval = startInterval + group_interval
                self.UserList[userId]['Groups'].append({"interval": [startInterval, endInterval], "contextId": [], "minLoss": 1, "minLossId": -1,
                               "probability": 0})  # 记录当前上下文的id
                startInterval = endInterval
        else:
            self.UserList[userId]['Groups'] = self.Update_UserGroup(userId)

        j = 0
        for loss in user_loss:
            for group in self.UserList[userId]['Groups']:  # 损失函数分组，组内记录item的vid就好了
                if group["interval"][0] <= loss and group["interval"][1] > loss:
                    group['contextId'].append(self.UserList[userId]["Contexts"][j].Get_vid())  # 记录的是当前loss对应的contextid，实际上也就是itemvid
                    if group['minLoss'] >= loss:
                        group['minLoss'] = loss
                        group['minLossId'] = self.UserList[userId]["Contexts"][j].Get_vid()
            j += 1
        return user_loss, self.UserList[userId]['Groups']

    def Update_UserGroup(self, userId):
        groups = self.UserList[userId]['Groups']
        group_interval = groups[0]['interval'][1] - groups[0]['interval'][0]
        zeta = group_interval*0.1
        for group in groups:
            p = random.random()
            if p >= 0.5:
                preStart = group['interval'][0]
                preEnd = group['interval'][1]
                group['interval'] = [preStart-zeta, preEnd +zeta]
        return groups

    def Update_UserContent(self, userId, videoId, delay):
        """return 更新过程就相当于segment的分发过程，所以记录下userId分发到videoId这个过程中的delay，和user（）的能耗？ """

        userParam = self.UserList[userId]
        cacheSize = userParam['cache_content_size']
        remainSize = userParam['Memory'] - cacheSize  # 当前user的Memory 和已经缓存内容的数值大小
        segSize = dat.video_dict[videoId]['size']
        ratio = 0

        # 先判断可存储空间的大小:不可存，删除首项内容，调整记录值
        while segSize > remainSize and len(userParam['cache_content'])!=0:
            # print("{}:当前要缓存的segSize为{}，缓存空闲空间大小{}".format(videoId,segSize,remainSize))
            # 删除内容首项
            popItem = userParam['cache_content'].pop(0)
            popItemId = popItem[0]
            userParam['cache_content_size'] = userParam['cache_content_size'] - dat.video_dict[popItemId]['size']
            remainSize += dat.video_dict[popItemId]['size']
            # print("要缓存的segSize为{}，需要删除的内容是{}，删除的videoSize={}，删除后的空闲size为{},缓存在user上的内容size"
            #       "为{}".format(segSize, popItem, dat.video_dict[popItemId]['size'], remainSize,userParam['cache_content_size']))

        # 要缓存的内容的size <= 可缓存空间size
        if segSize <= remainSize:
            # 将videoId 所代表的item加进去
            if userId in PS.Get_videoRequestedforUsers(videoId):
                # print("有存在的可能么？看一下当前userId:{} 和观看过videoId:{}的历史用户有{}".format(userId,videoId,PS.Get_videoRequestedforUsers(videoId)))
                # 在他历史观看目录里 找到对应评分条目加进来; 既然能进入if循环就一定能找到该item
                for item in PS.Get_User_Rate_Video(userId):
                    if item[0] == videoId:
                        newItem = item
                        # print("所以用户_{}观看video_{}的记录为{}".format(userId,videoId,item))
                        break
                    # print("{}在PS.Get_videoRequestedforUsers({})里，但是找不着{}=={}的情况".format(userId,videoId,item[0],videoId))
                # print("PS.Get_videoRequestedforUsers({})={}".format(userId,PS.Get_User_Rate_Video(userId)))
            else:
                rate = int(userParam['cache_aveRate']+1)
                newRate = int(random.randint(rate-2, rate if rate < 5 else 5 ))
                # 更新访问该video的user字典
                PS.videoRequestedforUsers[videoId].append(userId)
                newItem = [videoId, userParam['cache_aveRate'], int(time.time()), random.randint(1,20)]
                PS.User_Rate_Video[userId].append(newItem)
            # 把newitem添加进去，同时要更改user对应的 缓存size
            ratio += newItem[1]
            userParam['cache_content'].append(newItem)
            userParam['cache_content_size'] = userParam['cache_content_size'] + segSize
            # 调用平均分函数调整评分
            userParam['cache_aveRate'] = self.Update_rate(userParam['cache_content'])
            print("装入size={}的item={}后的已经缓存在user{}的content的size为{}".format(segSize, newItem, userId, userParam['cache_content_size']))
        else:
            delay = 0
        return delay, segSize, remainSize, ratio

    def Update_rate(self, cacheContent):
        sumRat = 0
        for item in cacheContent:
            sumRat += item[1]
        return sumRat/len(cacheContent)


    def Get_userContent(self,userId):
        return self.UserList[userId]