# written by biya
from Graph import FileReader as FR, GraphHelper as GH, Dag as D
from Graph import AuxiliaryNetwork as AN
import random
from Graph import ParameterSetting as PS
import matplotlib.pyplot as plt
import numpy as np
import logging
from algorithms.utils import uckm


def Rtest():
    MAX = 9999
    NetworkList = [30,50,100,200]
    FileName = '200-25-25.txt'
    FilePath = "E:/python1/Fighting/data/"
    Delta = 2 #MB

    # get NodeSet, EdgeSet  # ?????????????list
    dataReader = FR.MyFileReader()
    NodeSet, EdgeSet = dataReader.Get_Graph_Information(FilePath, FileName)

    NetworkData = GH.NetworkTepology(NodeSet, EdgeSet)
    NetworkData.Build_Network_Tepology()
    UserEntity = NetworkData.UserList    # {{UpstreamRate, downloadRate, Memory, Electricity}, cache_content, cache_content_size],[],[],...}

    d=random.randint(80,100)          # the number of users in a community
    N, Community, Community_num, neiborUserDict, NAp, NAp_edge= AN.ConstructLayer(NetworkData, NodeSet, EdgeSet, d)   #
    NetworkData.Build_BS(Community)   # build the bs in the community
    BSEntity = NetworkData.BSList
    DelayBD=[]
    DelayBS=[]

    for com in range(Community_num):

        flag = 2
        k = 0;

        # BSSet = BS-
        # ????community ? ??user? P_max, EB_min,
        userSet = Community[com]   #250
        P_user = []
        EB_user = []
        B_user = []
        for userId in userSet:
            P_user.append(UserEntity[userId][0]["LaunchPower"])
            EB_user.append(UserEntity[userId][0]["Electricity"])
            B_user.append(UserEntity[userId][0]["Memory"])

        P_max = max(P_user)
        EB_min = min(EB_user)
        B_min = min(B_user)
        capacity = (EB_min * Delta)/(P_max * B_min)
        print ("the capacity is:", capacity)

        numVirtualDe = int(B_min/Delta)  #  4
        virtualClList = [val for val in userSet for i in range(numVirtualDe)]
        print("the num of userSet in this community is:",len(userSet),"\n numVirtualDe in each device:",numVirtualDe,"\n the num of virtualClient is:",len(virtualClList))
        #("\n virtualClList:",virtualClList)
        numVirDe = numVirtualDe * len(userSet)

        numReq = int(EB_min / P_max)  # 5
        #numReq = random.randint(1, 10)  #???numReq?videoSeg
        ReqSegement = [random.randint(80,100)  for i in range(numReq)]
        print("this time, the num of req we had:", numReq) # 5
        #print("ReqSegment:",ReqSegement)
        BS_Ent = BSEntity[com]
        BS_name =  BS_Ent[0]
        if(k+numReq < len(BS_Ent[-1])):
            totalVideo = (BS_Ent[-1])[k:(k + numReq)]
            k = k + numReq
        else:
            totalVideo = (BS_Ent[-1])[k:]
            k = 0

        delayArr = np.zeros(shape=(numReq, numVirDe))
        for i in range(numReq):
            for j in range(numVirDe):
                delayArr[i][j] = NAp[BS_name][virtualClList[j]]["weight"]   # we suppose that all request from the BS
            #print("delayArr[i]", "i:",i, "delayArr[i]",delayArr[i].round(1)) #
        if numReq > numVirDe:
            addArr = delayArr.max(axis=1)  # axis = 1，指的是沿着行求所有列的平均值，代表了横轴，
            addArr = np.tile(
                np.expand_dims(addArr, axis=(1,)),
                (1, numReq - numVirDe)
            )
            addArr = MAX - addArr
            delayArr = np.c_[
                delayArr,
                addArr
            ]

        print("community:", com, "P_max:", P_max, "EB_min:", EB_min, " numReq:", numReq, "numVirtualDe:", numVirtualDe)

        result = uckm(                      # uckm?????????????
            distances = delayArr,                # ??????????
            numClient = numReq,                  # client ????? ?????????seg??
            numFacility = max(numReq, numVirDe)  # facility cloudlet??cloudlet????  ?????????user device
            )
        #resultDelay = result * delayArr

        #print("resultDelay:",resultDelay)
        #resultDelay[resultDelay == 0] = np.inf  #represent +∞，是没有确切的数值的,类型为浮点型
        newResult = np.sum(result, axis=1)
        print("newResult is :", newResult)
        for i in range(len(newResult)):
            if newResult[i] > capacity:
                cap = capacity
                for j in range(len(result[i])):
                    if result[i][j]>0:
                        cap -= result[i][j]
                        result[i][j] = 0
                    if(cap >= sum(result[i])):
                        break


    return result

if __name__ == '__main__':
    Rtest() # we just use the segments from bs