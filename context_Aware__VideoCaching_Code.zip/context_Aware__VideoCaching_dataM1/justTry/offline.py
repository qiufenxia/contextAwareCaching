# written by biya
import numpy as np
from algorithms.utils import uckm
from Graph import ParameterSetting as PS
from Graph import data0 as dat
import torch
import math

Delta = 1 #Mb
MAX = 9999

def offline(pathFromUser, UserEntity, user, userSet, type, predictedResult):
    """
    :param capacity: 用于之后的比较是否可以将segment缓存到该设备上，没有使用ol的直接可以总的capacity对比也就是对于所用segment的请求均为1
                     有了ol之后，capacity更偏向于存储本设备预测的概率较大的segment组
    :param user: 存储当前要分发的segment的 user
    :param userSet: 参与接收segment的device
    :param seg: segment的数目（可以通过user获取）
    :param type: 使用 type 来表示当前capacity的类型：0 表示原始数值个数，对结果直接进行置零操作就行；
                                                  1 表示使用OL算法后得到的
    :param predictedResult: 传入ol前面预测的每个设备对于level组的偏好 {'user77': [{'level': 1389, 'probability': 0.2000048937965055}, {'level': 216, 'prop.....},....],.....}
    应该是当前所用用户所预测出来的结果的一个累加；不用OL的预测结果就是1
    :return: 缓存位置的结果
    """
    P_user = []
    EB_user = []
    B_user = []
    user_prefer = {}
    predictedRes = []

    for userId in userSet:
        P_user.append(UserEntity[userId]["LaunchPower"])
        EB_user.append(UserEntity[userId]["Electricity"])
        B_user.append(UserEntity[userId]["Memory"])
     # 处理每个device 对groups 的偏好
        # 操作偏好{userId:{[min,max]:probability,[min,max]:pro,....}}
        for item_dict in predictedResult['user'+str(userId)]:
            predictedRes.append([0 if item_dict['level'] - 3 <= 0 else item_dict['level'] - 3, item_dict['level'] + 3, item_dict['probability']])

    predictedRes = sorted(predictedRes, key=(lambda x: x[0]))
    # print("pre_sort_alluser_prefer is {}".format(predictedRes))

    # 重叠组合并
    left = 0
    for right in range(len(predictedRes) - 1):
        if predictedRes[right + 1][0] <= predictedRes[left][1]:
            if predictedRes[left][1] < predictedRes[right + 1][1]:
                predictedRes[left][1] = predictedRes[right + 1][1]
            predictedRes[left][2] += predictedRes[right + 1][2]
        else:
            left += 1
            predictedRes[left] = predictedRes[right + 1]

    predictedRes = sorted(predictedRes[:left + 1], key=(lambda x: x[2]),reverse=True)
    print("sorted_alluser_prefer is {}".format(predictedRes))

    P_max = max(P_user)
    EB_min = min(EB_user)
    B_min = min(B_user)
    # 每个设备可以服务的请求数量
    numOfReq = EB_min / P_max
    capacity = math.floor((EB_min * Delta) / (P_max * B_min))
    print("令人头疼的capacity={}",capacity)

    # 划定每个device 的虚拟device的数量 并显性表示
    numVirtualDe = int(B_min/Delta)  #  4
    virtualClList = [val for val in userSet for i in range(numVirtualDe)]
    # print("virtualClList:",virtualClList)
    # print("the num of userSet in this community is:",len(userSet),"\n numVirtualDe in each device:",numVirtualDe,"\n the num of virtualClient is:",len(virtualClList))
    # print("\n virtualClList:",virtualClList)
    numVirDe = numVirtualDe * len(userSet)
    numOfeachDevice = [numVirtualDe for i in range(len(userSet)) ]

    # 要分发的视频段的个数(视频分段，存储为相同size的segment)作为请求数目（这块记录的是当前设备上已经缓存的所有内容数目）
    video = UserEntity[user]['cache_content']
    segIds = []
    videoIds = []
    numOfeachSeg = []
    levelOfVide = []

    for vItem in video:
        vid = vItem[0]
        videoIds.append(vid)
        video_size = dat.video_dict[vid]['size']
        segnum = math.ceil(video_size /Delta)
        numOfeachSeg.append(segnum)
        # 记录当前video组的对应level
        levelOfVide.append(PS.Get_videoCount()[vid])
        for i in range(segnum):
            segIds.append (vid) #
        # print("当前video{}的size为{}，可以分成{}个segment，segIds：{}".format(vid,video_size,segnum,segIds))
    numReq = len(segIds)

    # 记录当前segment组的对应level
    # levelOfVide = [PS.Get_videoCount()[id] for id  in segIds]
    # 得到 每个segment 的capacity ，概率*capacity，判断当前Seg的level的是否在
    capacityOfvide = []
    for Seg_level in levelOfVide:
        for predict_item in predictedRes:
            if Seg_level >= predict_item[0] and Seg_level < predict_item[1]:
                capacityOfvide.append(math.floor(capacity * predict_item[2]))
            else:
                capacityOfvide.append(capacity)
            # print("当前的Seg_level是{}，predict_item是{}".format(Seg_level,predict_item))

    print("当前的segment的id 是{},其对应的level是{}，capacityOfSeg是{}".format(segIds, levelOfVide, capacityOfvide))
    DelayOfVide = np.zeros(shape=(len(video),len(userSet)))

    # video-device的delay数组
    for a in range(len(video)):
        for b in range(len(userSet)):
            DelayOfVide[a][b] = pathFromUser[userSet[b]]["weight"]   / PS.Get_LaunchPower() + dat.video_dict[video[a][0]]['size'] / PS.Get_UpstreamRate() \
                         + dat.video_dict[video[a][0]]['size'] / PS.Get_DownloadRate()
    delayArrx = DelayOfVide.repeat(numOfeachDevice, axis=1)
    delayArr = delayArrx.repeat(numOfeachSeg, axis=0)

    if numReq > numVirDe:
        addArr = delayArr.max(axis=1)  # axis = 1，指的是沿着行求所有列的平均值，代表了横轴，
        addArr = np.tile(
            np.expand_dims(addArr, axis=(1,)),
            (1, numReq - numVirDe)
        )
        addArr = MAX - addArr
        delayArr = np.c_[
            delayArr,
            addArr
        ]

    # print( "P_max:", P_max, "EB_min:", EB_min, " numReq:", numReq, "numVirtualDe:", numVirtualDe)

    result = uckm(
        distances = delayArr,
        numClient = numReq,  # video被分成同样大小的总的segment数量
        numFacility = max(numReq, numVirDe)
        )

    # 对取到的结果进行处理 同样vid 的多行合成一行
    result = mergeSameSegeReg(result, numOfeachSeg, 0)
    # 对取到的结果进行处理 同样 deviceid 的多列合成一行
    result = mergeSameSegeReg(result, numOfeachDevice, 1)
    new_result  = np.int64(result > 0)
    print("new_result is :", new_result)

    newResult = np.sum(new_result, axis=1) # 横轴（每行）加和
    print("newResult is :", newResult)

    """我是uckm和uckm之后进行操作的完美分解线"""

    for i in range(len(newResult)): # segment的数量
        # 判断segment的实际请求是否超过其能供应的请求
        print("当前segment 放置数量是:{} ,可放置数量是:{}".format(newResult[i],capacityOfvide[i]))
        if newResult[i] > capacityOfvide[i]:  # capacity 指的每个segment所能承受的device的容量，换句话说就是一个segment被请求的device数目不能超过其capacity
            # 若超过：记录当前segment所能供应最多请求数,
            """ 根据当前Q级预测概率去计算当前user对当前item的capacity：预测概率 p * capacity """
            cap = capacityOfvide[i]

            # 遍历该segment实际供应device情况,
            k = 0
            while (sum(new_result[i]) > cap):
                for j in range(len(new_result[i])):
                   # 先把>1的都重置为1
                    if k== 0 and new_result[i][j] > 1:
                        # cap = cap - result[i][j] + 1 #用概率判断，
                        new_result[i][j] = 1
                        # print("重置后的cap是{}".format(cap))
                    elif k == 1 and new_result[i][j] == 1 and (sum(new_result[i]) > cap):
                        new_result[i][j] = 0
                    elif sum(new_result[i]) == 0:
                        break
                k = 1
# 返回 segment可放置的device的对应编号
    list_cache = torch.tensor(new_result)
    print("list_cache is {}".format(list_cache))
    list_cache_result = torch.nonzero(torch.where(list_cache == 1, torch.tensor(1), torch.tensor(0))).tolist() # 取到可放置的index
    print("list_cache_result is {}".format(list_cache_result))
    cache_result = [{"segId": videoIds[i], "deviceId": userSet[j], "delay":DelayOfVide[i][j]}for i,j in list_cache_result ]
    print("cache_result is {}".format(cache_result))
    return result, cache_result


def mergeSameSegeReg(result, num, f):
    """
    result : 要处理的矩阵
    num : 记录重复次数的列表 eg；【2， 2 ，1】：2行/列加和，2行/列加和，1行/列加和
    """
    # 对取到的结果进行处理 同样vid 的多行合成一行
    startIndex = 0
    if f == 0:
        new_result = np.zeros((0, result.shape[1]))
        for i in range(len(num)):
            a = np.sum(result[startIndex:(startIndex + num[i]), :], axis=0)
            startIndex = startIndex + num[i]
            new_result = np.vstack((new_result, a))
        print("new_result is {}".format(new_result))
    elif f == 1:
        # 对不同列上的值加和合并
        new_result = []
        for i in range(len(num)):
            a = np.sum(result[:, startIndex:(startIndex + num[i])], axis=1)
            new_result.append(a)
            startIndex = startIndex + num[i]

        new_result = np.transpose(new_result)
    return new_result





