# -*- coding: latin-1 -*-
from Graph import FileReader as FR, GraphHelper as GH, Dag as D
from Graph import AuxiliaryNetwork as AN
import random
from Graph import ParameterSetting as PS
import matplotlib.pyplot as plt   # ??????
import numpy as np
import logging
from algorithms.utils import uckm


def Rtest1():
    """
    # in this way, we suppose the segement from some users
    # first we should set two userSets which video requestor and video recipent
    # in this community, we have the total userSet, supposing the vide is set in user k, we can get the location for the segement in user k.
    """
    MAX = 9999

    NetworkList = [30,50,100,200]
    FileName = '200-25-25.txt'
    FilePath = "E:/python1/Fighting/data/"
    Delta = 1 #Mb

    # get NodeSet, EdgeSet  # list
    dataReader = FR.MyFileReader()
    NodeSet, EdgeSet = dataReader.Get_Graph_Information(FilePath, FileName)

    NetworkData = GH.NetworkTepology(NodeSet, EdgeSet)
    NetworkData.Build_Network_Tepology()
    UserEntity = NetworkData.UserList    # {{UpstreamRate, downloadRate, Memory, Electricity}, cache_content, cache_content_size],[],[],...}

    d=random.randint(80,100)          # the number of users in a community
    N, Community, Community_num, neiborUserDict, NAp, NAp_edge= AN.ConstructLayer(NetworkData, NodeSet, EdgeSet, d)   #
    NetworkData.Build_BS(Community)   # builde the bs in the community
    BSEntity = NetworkData.BSList

    for com in range(Community_num):
        k = 0
        userSet0 = Community[com]
        for user in userSet0:
            seg = UserEntity[user][-2]
            # user's neibourSet
            userSet = neiborUserDict[user]
            P_user = []
            EB_user = []
            B_user = []
            for userId in userSet:
                P_user.append(UserEntity[userId][0]["LaunchPower"])
                EB_user.append(UserEntity[userId][0]["Electricity"])
                B_user.append(UserEntity[userId][0]["Memory"])

            P_max = max(P_user)
            EB_min = min(EB_user)
            B_min = min(B_user)
            capacity = (EB_min * Delta) / (P_max * B_min)
            print("???capacity?{}".format(capacity))

            numVirtualDe = int(B_min/Delta)  #
            virtualClList = [val for val in userSet for i in range(numVirtualDe)]
            print("userSet:",userSet,"numVirtualDe:",numVirtualDe,"virtualClList:",virtualClList)
            numVirDe = numVirtualDe * len(userSet)

            #numReq = int(EB_min / P_max)  #
            #numReq = random.randint(10, 50)  # numReq?videoSeg
            numReq = len(seg)
            # BS_Ent = BSEntity[com]
            # BS_name =  BS_Ent[0]
            # totalVideo = (BS_Ent[-1])[k:(k+numReq)] #
            k = k + numReq

            delayArr = np.zeros(shape=(numReq, numVirDe))
            for i in range(numReq):
                for j in range(numVirDe):
                    delayArr[i][j] = NAp[user][virtualClList[j]]["weight"]   # the delay between user and his neighbor
            if numReq > numVirDe:
                addArr = delayArr.max(axis=1)  # axis = 1??????????????????????
                addArr = np.tile(
                    np.expand_dims(addArr, axis=(1,)),
                    (1, numReq - numVirDe)
                )
                addArr = MAX - addArr
                delayArr = np.c_[
                    delayArr,
                    addArr
                ]

            print("community:", com, "P_max:", P_max, "EB_min:", EB_min, " numReq:", numReq, "numVirtualDe:",
                  numVirtualDe)

            #print("??community?P_max:", P_max, "EB_min:", EB_min, " numReq:", numReq, "numVirtualDe:", numVirtualDe)

            result = uckm(
                distances=delayArr,
                numClient=numReq,
                numFacility=max(numReq, numVirDe)
                )
            newResult = np.sum(result, axis=1)
            print("newResult is :", newResult)
            for i in range(len(newResult)):
                # ??segment????????????????
                if newResult[i] > capacity:
                    # ????????segment?????????
                    cap = capacity
                    # ???segment????device??
                    for j in range(len(result[i])):
                        # ???segment???j?device
                        if result[i][j] > 0:
                            cap -= result[i][j]
                            result[i][j] = 0
                        if (cap >= sum(result[i])):
                            break

if __name__ == '__main__':
    Rtest1()