# written by biya
def loss(numUSeg):


